/****/ 
module.exports = {
  content: ['./src/renderer/**/*.{ts,tsx,html}'],
  theme: {
    extend: {},
  },
  plugins: [],
};
